# OWASP Güvenlik Tarayıcısı - Bağımsız Deployment Rehberi

## Ücretsiz Hosting Seçenekleri

### 1. Railway (Önerilen)
**Ücretsiz:** 500 saat/ay, otomatik SSL

1. [railway.app](https://railway.app) hesabı oluşturun
2. GitHub'a projeyi yükleyin
3. Railway'de "Deploy from GitHub" seçin
4. Environment Variables:
   ```
   SESSION_SECRET=your-secret-key-here
   DATABASE_URL=postgresql://... (Railway otomatik verir)
   ```

### 2. Render
**Ücretsiz:** Sınırsız, ama yavaş başlatma

1. [render.com](https://render.com) hesabı oluşturun
2. "New Web Service" → GitHub repository
3. Build Command: `pip install -r requirements.txt`
4. Start Command: `gunicorn --bind 0.0.0.0:$PORT main:app`

### 3. Fly.io
**Ücretsiz:** 160 GB/ay transfer

1. [fly.io](https://fly.io) hesabı oluşturun
2. `flyctl` CLI kurumu yapın
3. Proje klasöründe: `fly launch`

### 4. Heroku (Artık ücretli)
Ücretsiz plan kaldırıldı, aylık $5-7

## Replit Deployments (Kolay Seçenek)

1. Replit projenizde "Deploy" butonuna basın
2. "Autoscale" seçeneğini seçin
3. Aylık $7-20 arası ücret
4. Otomatik domain: `yourapp.replit.app`

## GitHub'a Yükleme Adımları

```bash
# Git repository oluşturun
git init
git add .
git commit -m "OWASP Security Scanner"

# GitHub'a push edin
git remote add origin https://github.com/username/owasp-scanner.git
git push -u origin main
```

## Production için Gerekli Değişiklikler

app.py dosyasında:
```python
import os
from flask import Flask

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback-key")

# Production database
if os.environ.get("DATABASE_URL"):
    app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
else:
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///scanner.db"
```

## Önerilen Platform: Railway

Railway en kolay ve güvenilir seçenek:
- Otomatik SSL/HTTPS
- Ücretsiz PostgreSQL
- Kolay GitHub entegrasyonu
- Hızlı deployment