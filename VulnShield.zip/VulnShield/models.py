from app import db
from datetime import datetime

class ScanResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    target_url = db.Column(db.String(500), nullable=False)
    scan_date = db.Column(db.DateTime, default=datetime.utcnow)
    vulnerabilities_found = db.Column(db.Integer, default=0)
    high_severity = db.Column(db.Integer, default=0)
    medium_severity = db.Column(db.Integer, default=0)
    low_severity = db.Column(db.Integer, default=0)
    scan_results = db.Column(db.Text)  # JSON string of detailed results
    
    def __repr__(self):
        return f'<ScanResult {self.target_url}>'

class Vulnerability(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    scan_result_id = db.Column(db.Integer, db.ForeignKey('scan_result.id'), nullable=False)
    vulnerability_type = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.String(20), nullable=False)  # High, Medium, Low
    description = db.Column(db.Text, nullable=False)
    recommendation = db.Column(db.Text, nullable=False)
    owasp_category = db.Column(db.String(100), nullable=False)
    
    scan_result = db.relationship('ScanResult', backref=db.backref('vulnerabilities', lazy=True))
    
    def __repr__(self):
        return f'<Vulnerability {self.vulnerability_type}>'
