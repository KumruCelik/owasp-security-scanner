from flask import render_template, request, jsonify, redirect, url_for, flash
from app import app, db
from models import ScanResult, Vulnerability
from vulnerability_scanner import VulnerabilityScanner
import json
from datetime import datetime
import logging

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scan', methods=['POST'])
def scan_website():
    target_url = request.form.get('url', '').strip()
    
    if not target_url:
        flash('Lütfen taranacak URL\'yi girin.', 'error')
        return redirect(url_for('index'))
    
    # Add protocol if missing
    if not target_url.startswith(('http://', 'https://')):
        target_url = 'https://' + target_url
    
    try:
        # Initialize scanner and perform scan
        scanner = VulnerabilityScanner()
        scan_results = scanner.scan_url(target_url)
        
        # Save scan results to database
        scan_record = ScanResult(
            target_url=target_url,
            vulnerabilities_found=len(scan_results['vulnerabilities']),
            high_severity=len([v for v in scan_results['vulnerabilities'] if v['severity'] == 'Yüksek']),
            medium_severity=len([v for v in scan_results['vulnerabilities'] if v['severity'] == 'Orta']),
            low_severity=len([v for v in scan_results['vulnerabilities'] if v['severity'] == 'Düşük']),
            scan_results=json.dumps(scan_results, ensure_ascii=False)
        )
        
        db.session.add(scan_record)
        db.session.commit()
        
        # Save individual vulnerabilities
        for vuln in scan_results['vulnerabilities']:
            vulnerability = Vulnerability(
                scan_result_id=scan_record.id,
                vulnerability_type=vuln['type'],
                severity=vuln['severity'],
                description=vuln['description'],
                recommendation=vuln['recommendation'],
                owasp_category=vuln['owasp_category']
            )
            db.session.add(vulnerability)
        
        db.session.commit()
        
        return render_template('scan_result.html', 
                             scan_results=scan_results, 
                             target_url=target_url,
                             scan_id=scan_record.id)
        
    except Exception as e:
        logging.error(f"Scan error: {str(e)}")
        flash(f'Tarama sırasında hata oluştu: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/history')
def scan_history():
    scans = ScanResult.query.order_by(ScanResult.scan_date.desc()).limit(20).all()
    return render_template('history.html', scans=scans)

@app.route('/scan/<int:scan_id>')
def view_scan(scan_id):
    scan = ScanResult.query.get_or_404(scan_id)
    scan_results = json.loads(scan.scan_results)
    return render_template('scan_result.html', 
                         scan_results=scan_results, 
                         target_url=scan.target_url,
                         scan_id=scan.id)

@app.route('/export/<int:scan_id>')
def export_scan(scan_id):
    scan = ScanResult.query.get_or_404(scan_id)
    scan_results = json.loads(scan.scan_results)
    
    # Create a simple text report
    report = f"""
OWASP Top 10 Güvenlik Tarama Raporu
=====================================

Hedef URL: {scan.target_url}
Tarama Tarihi: {scan.scan_date.strftime('%d.%m.%Y %H:%M')}
Toplam Zafiyet: {scan.vulnerabilities_found}

Önem Seviyesi Dağılımı:
- Yüksek: {scan.high_severity}
- Orta: {scan.medium_severity}  
- Düşük: {scan.low_severity}

Detaylar:
=========
"""
    
    for vuln in scan_results['vulnerabilities']:
        report += f"""
{vuln['type']} - {vuln['severity']}
OWASP Kategorisi: {vuln['owasp_category']}
Açıklama: {vuln['description']}
Öneri: {vuln['recommendation']}
---
"""
    
    from flask import Response
    return Response(
        report,
        mimetype='text/plain',
        headers={'Content-Disposition': f'attachment;filename=scan_report_{scan_id}.txt'}
    )

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500
