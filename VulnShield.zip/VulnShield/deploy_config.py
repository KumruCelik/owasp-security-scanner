# Deployment Configuration for Different Platforms

# Heroku Configuration
HEROKU_CONFIG = {
    'buildpacks': ['heroku/python'],
    'python_version': '3.11',
    'web_process': 'gunicorn --bind 0.0.0.0:$PORT main:app'
}

# Railway Configuration  
RAILWAY_CONFIG = {
    'start_command': 'gunicorn --bind 0.0.0.0:$PORT main:app',
    'python_version': '3.11'
}

# Render Configuration
RENDER_CONFIG = {
    'build_command': 'pip install -r requirements.txt',
    'start_command': 'gunicorn --bind 0.0.0.0:$PORT main:app'
}

# Environment Variables needed for production
REQUIRED_ENV_VARS = [
    'DATABASE_URL',  # PostgreSQL for production
    'SESSION_SECRET',  # Flask secret key
    'FLASK_ENV'  # production
]