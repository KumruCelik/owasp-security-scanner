# OWASP Top 10 Güvenlik Tarayıcısı - Kurulum Kılavuzu

## Gereksinimler
- Python 3.8 veya üzeri
- pip (Python paket yöneticisi)

## Adım 1: Dosyaları İndirin

### Manuel İndirme (Replit'ten):
1. Replit'te sol panelden şu dosyaları tek tek indirin:
   - `app.py`
   - `main.py` 
   - `models.py`
   - `routes.py`
   - `vulnerability_scanner.py`
   - `pyproject.toml`

2. Klasörleri indirin:
   - `templates/` klasörü (tüm HTML dosyaları)
   - `static/` klasörü (CSS, JS, SVG dosyaları)

## Adım 2: Proje Klasörü Oluşturun
```bash
mkdir owasp-scanner
cd owasp-scanner
```

İndirilen dosyaları bu klasöre koyun.

## Adım 3: Gerekli Paketleri Yükleyin

`requirements.txt` dosyası oluşturun:
```
Flask==2.3.3
Flask-SQLAlchemy==3.0.5
gunicorn==21.2.0
requests==2.31.0
beautifulsoup4==4.12.2
email-validator==2.0.0
sqlalchemy==2.0.21
werkzeug==2.3.7
```

Paketleri yükleyin:
```bash
pip install -r requirements.txt
```

## Adım 4: Uygulamayı Çalıştırın

### Geliştirme Modu:
```bash
python main.py
```

### Üretim Modu:
```bash
gunicorn --bind 0.0.0.0:5000 main:app
```

## Adım 5: Tarayıcıda Açın
http://localhost:5000 adresine gidin

## Klasör Yapısı
```
owasp-scanner/
├── app.py
├── main.py
├── models.py
├── routes.py
├── vulnerability_scanner.py
├── requirements.txt
├── templates/
│   ├── base.html
│   ├── index.html
│   └── scan_result.html
└── static/
    ├── css/
    │   └── style.css
    ├── js/
    │   └── main.js
    └── assets/
        └── security-icon.svg
```

## Özellikler
- OWASP Top 10 güvenlik taraması
- Türkçe arayüz
- Zafiyet raporları
- PDF rapor indirme
- Bootstrap tabanlı modern tasarım
- SQLite veritabanı

## Notlar
- İlk çalışmada SQLite veritabanı otomatik oluşturulur
- Tüm tarama sonuçları veritabanında saklanır
- Uygulama eğitim amaçlı simülasyon yapar