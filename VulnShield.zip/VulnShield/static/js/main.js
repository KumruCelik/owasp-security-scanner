// Main JavaScript file for OWASP Security Scanner

document.addEventListener('DOMContentLoaded', function() {
    console.log('OWASP Security Scanner initialized');
    
    // Initialize components
    initializeFormValidation();
    initializeTooltips();
    initializeProgressBars();
    initializeScanForm();
});

/**
 * Initialize form validation
 */
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
}

/**
 * Initialize Bootstrap tooltips
 */
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Initialize progress bars with animation
 */
function initializeProgressBars() {
    const progressBars = document.querySelectorAll('.progress-bar');
    
    progressBars.forEach(bar => {
        const targetWidth = bar.style.width || bar.getAttribute('aria-valuenow') + '%';
        bar.style.width = '0%';
        
        setTimeout(() => {
            bar.style.transition = 'width 1.5s ease-in-out';
            bar.style.width = targetWidth;
        }, 500);
    });
}

/**
 * Initialize scan form with enhanced UX
 */
function initializeScanForm() {
    const scanForm = document.getElementById('scanForm');
    const urlInput = document.getElementById('url');
    const scanBtn = document.getElementById('scanBtn');
    
    if (!scanForm || !urlInput || !scanBtn) return;
    
    // URL input validation and formatting
    urlInput.addEventListener('blur', function() {
        let url = this.value.trim();
        
        if (url && !url.match(/^https?:\/\//)) {
            // Add https:// if no protocol specified
            url = 'https://' + url;
            this.value = url;
        }
        
        // Validate URL format
        if (url && !isValidUrl(url)) {
            this.setCustomValidity('Lütfen geçerli bir URL girin');
            this.classList.add('is-invalid');
        } else {
            this.setCustomValidity('');
            this.classList.remove('is-invalid');
            if (url) this.classList.add('is-valid');
        }
    });
    
    // Form submission handling
    scanForm.addEventListener('submit', function(e) {
        const url = urlInput.value.trim();
        if (!url || !isValidUrl(url)) {
            e.preventDefault();
            showAlert('Lütfen geçerli bir URL girin.', 'danger');
            return;
        }
        
        // Show loading state but let form submit normally
        showLoadingState();
    });
    
    // Real-time URL validation
    urlInput.addEventListener('input', function() {
        const url = this.value.trim();
        const isValid = !url || isValidUrl(url) || isPartialUrl(url);
        
        this.classList.toggle('is-invalid', !isValid && url.length > 0);
        scanBtn.disabled = !isValid || !url;
    });
}

/**
 * Validate URL format
 */
function isValidUrl(string) {
    try {
        const url = new URL(string);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
        return false;
    }
}

/**
 * Check if string could be a partial URL
 */
function isPartialUrl(string) {
    const domainPattern = /^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
    return domainPattern.test(string) || string.includes('.');
}

/**
 * Show loading state during scan
 */
function showLoadingState() {
    const scanBtn = document.getElementById('scanBtn');
    const spinner = scanBtn?.querySelector('.spinner-border');
    const loadingModal = document.getElementById('loadingModal');
    
    if (scanBtn) {
        scanBtn.disabled = true;
        scanBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Taranıyor...';
    }
    
    if (spinner) {
        spinner.classList.remove('d-none');
    }
    
    if (loadingModal) {
        const modal = new bootstrap.Modal(loadingModal);
        modal.show();
        
        // Simulate progress
        simulateProgress();
    }
}

/**
 * Simulate scanning progress
 */
function simulateProgress() {
    const progressBar = document.querySelector('#loadingModal .progress-bar');
    if (!progressBar) return;
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 95) progress = 95;
        
        progressBar.style.width = progress + '%';
        progressBar.setAttribute('aria-valuenow', progress);
        
        if (progress >= 95) {
            clearInterval(interval);
        }
    }, 300);
}

/**
 * Show alert message
 */
function showAlert(message, type = 'info') {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
    alertContainer.innerHTML = `
        <i class="fas fa-${getIconForAlertType(type)} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.container');
    if (container) {
        container.insertBefore(alertContainer, container.firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertContainer.parentNode) {
                alertContainer.remove();
            }
        }, 5000);
    }
}

/**
 * Get icon for alert type
 */
function getIconForAlertType(type) {
    const icons = {
        'success': 'check-circle',
        'danger': 'exclamation-triangle',
        'warning': 'exclamation-circle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

/**
 * Copy text to clipboard
 */
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showAlert('Metin panoya kopyalandı!', 'success');
    }).catch(() => {
        showAlert('Kopyalama işlemi başarısız oldu.', 'danger');
    });
}

/**
 * Format date for display
 */
function formatDate(date) {
    return new Intl.DateTimeFormat('tr-TR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date(date));
}

/**
 * Animate counters
 */
function animateCounter(element, target) {
    let current = 0;
    const increment = target / 50;
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            current = target;
            clearInterval(timer);
        }
        element.textContent = Math.ceil(current);
    }, 40);
}

/**
 * Initialize counter animations when elements come into view
 */
function initializeCounterAnimations() {
    const counters = document.querySelectorAll('[data-counter]');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = parseInt(entry.target.getAttribute('data-counter'));
                animateCounter(entry.target, target);
                observer.unobserve(entry.target);
            }
        });
    });
    
    counters.forEach(counter => observer.observe(counter));
}

/**
 * Handle export functionality
 */
function handleExport(scanId) {
    const exportBtn = document.querySelector(`[data-scan-id="${scanId}"]`);
    if (exportBtn) {
        exportBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>İndiriliyor...';
        exportBtn.disabled = true;
        
        setTimeout(() => {
            exportBtn.innerHTML = '<i class="fas fa-download me-2"></i>Raporu İndir';
            exportBtn.disabled = false;
        }, 2000);
    }
}

// Global functions for inline event handlers
window.copyToClipboard = copyToClipboard;
window.handleExport = handleExport;

// Initialize additional features when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeCounterAnimations();
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const href = this.getAttribute('href');
            if (href && href !== '#') {
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
});
